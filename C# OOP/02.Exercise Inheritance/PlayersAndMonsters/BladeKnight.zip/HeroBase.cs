﻿namespace PlayersAndMonsters
{
    public class HeroBase
    {
    }
}