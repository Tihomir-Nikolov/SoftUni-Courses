﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Farm
{
    class Animil
    {
        public void Eat() 
        {
            Console.WriteLine("eating...");
        }
    }
}
