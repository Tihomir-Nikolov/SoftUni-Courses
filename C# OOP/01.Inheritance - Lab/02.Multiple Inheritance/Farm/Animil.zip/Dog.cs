﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Farm
{
    class Dog : Animil
    {
        public void Bark() 
        {
            Console.WriteLine("barking...");
        }

    }
}
